

using System;
using MySql.Data.MySqlClient;

namespace ISAD157
{
    class DBConnect
    {

        internal const string USER_NAME = "ISAD157_MMares";

        internal const string SERVER = "proj-mysql.uopnet.plymouth.ac.uk";

        internal const string DATABASE_NAME = "ISAD157_MMares";

        internal const string PASSWORD = "ISAD157_22216983";
      
        internal const string SslMode = "none";

    } 
}
